#ifndef SOLUCION2DOPARCIALCLIENTES_H
#define SOLUCION2DOPARCIALCLIENTES_H


void bonificarClientes(const char* clientes, const char* clientesInd, const char* ventas);
void listarClientesOrdXBonifDesc(const char* clientes);


#endif // SOLUCION2DOPARCIALCLIENTES_H

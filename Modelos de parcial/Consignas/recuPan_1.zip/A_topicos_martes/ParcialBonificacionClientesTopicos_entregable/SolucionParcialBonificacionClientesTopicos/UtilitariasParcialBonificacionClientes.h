#ifndef UTILITARIAS2DOPARCIALCLIENTES_H
#define UTILITARIAS2DOPARCIALCLIENTES_H


void generarArchivoClientes();
void generarIndiceArchivoClientes();
void generarArchivoVentas();
void mostrarArchivoClientes();
void mostrarArchivoVentas();


#endif // UTILITARIAS2DOPARCIALCLIENTES_H

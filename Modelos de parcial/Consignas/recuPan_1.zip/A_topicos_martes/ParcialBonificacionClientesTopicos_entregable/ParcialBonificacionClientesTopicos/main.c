#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../SolucionParcialBonificacionClientesTopicos/UtilitariasParcialBonificacionClientes.h"
#include "../SolucionParcialBonificacionClientesTopicos/SolucionParcialBonificacionClientes.h"
#include "../SolucionParcialBonificacionClientesTopicos/TiposArchivos.h"

#define TDA_LISTA_IMPL_DINAMICA_VEC
#include "../TDALista/TDALista.h"

#define NO_FILE -999

///DATOS: CORONEL; THIAGO MARTIN 44834604
typedef struct
{
    void* dirI;
    size_t ce;
    size_t tam;
    size_t tamTD;
} tVector;

typedef void (*accion_ALU)(void*);
typedef int (*cpm_ALU)(void*, void*);
typedef void (*Actualizar_ALU)(void*, void*);
///Primitivas de TDA VECTOR
int tVectorCrear_ALU(tVector* vec, size_t tamElem, int cant);
int tVectorInsertarAlFinal_ALU(tVector* vec, void* elem);
int tVectorInsertarOrdenadoyActualizar_ALU(tVector * vec, void* elem, cpm_ALU comp, Actualizar_ALU fusionar);
void tVectorMostrar_ALU(tVector* vec, accion_ALU mostrar);
void tVectorDestruir_ALU(tVector* vec);
void* busquedaBinaria_ALU(tVector* vecVentas, void* elem, cpm_ALU comp);
///Funciones particulares
void mostrarIdx_ALU(void* a);
void mostrarVentas_ALU(void* i);
void mostrarClientes_ALU(void* a);
int compararVentas_ALU(void* a, void* b);
int compararBusquedaBin_ALU(void* a, void* b);
int compararOrdenamiento_ALU(void* a, void* b);

///Ordenamiento
void intercambiar_ALU(void* a, void*b, size_t tamTD);
void ordenarSeleccionGen_ALU(tVector* vec, cpm_ALU comparacion);
void* buscarMm_ALU(void* inicio, void* fin, size_t tamTD, cpm_ALU comparacion);
///PARCIAL
int bonificarClientes_ALU(const char* clientes, const char* clientesInd, const char* ventas);
void listarClientesOrdXBonifDesc_ALU(const char* clientes);

int main()
{
    generarArchivoClientes();
    generarIndiceArchivoClientes();
    generarArchivoVentas();

    mostrarArchivoClientes();
    puts("\n");

    mostrarArchivoVentas();
    puts("\n");


    bonificarClientes_ALU("Clientes.dat", "Clientes.idx", "Ventas.dat");
    //bonificarClientes("Clientes.dat", "Clientes.idx", "Ventas.dat");

	puts("Clientes Bonificados");
	mostrarArchivoClientes();
	puts("\n");

    listarClientesOrdXBonifDesc_ALU("Clientes.dat");
    //listarClientesOrdXBonifDesc("Clientes.dat");

    return 0;
}
int tVectorCrear_ALU(tVector* vec, size_t tamElem, int cant)
{
    void* direccion = malloc(cant * tamElem);
    if (!direccion)
    {
        printf("No se pudo reservar memoria\n");
        return SIN_MEM;
    }
    vec->dirI = direccion;
    vec->ce = 0;
    vec->tam = cant;
    vec->tamTD = tamElem;
    return TODO_OK;
}
int tVectorInsertarAlFinal_ALU(tVector* vec, void* elem)
{
    void* dirAInsertar = vec->dirI + vec->ce * vec->tamTD; ///inserto al final
    if(vec->ce == vec->tam)
    {
        size_t nuevoCap = vec->tam * 2;
        void* aux = realloc(vec->dirI, nuevoCap * vec->tamTD);
        if(!aux)
            return SIN_MEM;
        vec->dirI = aux;
        vec->tam = nuevoCap;
    }
    memcpy(dirAInsertar, elem, vec->tamTD);
    vec->ce++;
    return TODO_OK;
}
void tVectorDestruir_ALU(tVector* vec)
{
    free(vec->dirI);
}
void mostrarIdx_ALU(void* a)
{
    Indice ind = *(Indice*)a;
    printf("%d | %s\n", ind.nroReg, ind.codCliente);
}
void tVectorMostrar_ALU(tVector* vec, accion_ALU mostrar)
{
    void* i;
    void* ult = vec->dirI + (vec->ce-1)*vec->tamTD;
    for(i = vec->dirI; i <= ult; i+= vec->tamTD)
    {
        mostrar(i);
    }
}

int compararVentas_ALU(void* a, void* b)
{
    Venta *aux1 = (Venta*)a;
    Venta *aux2 = (Venta*)b;
    return strcmpi(aux1->codCliente, aux2->codCliente);
}

void actualizarVentas_ALU(void* i, void* elem)
{
    Venta *pos = (Venta*)i;
    Venta *aux = (Venta*)elem;
    pos->precioUnit += aux->precioUnit;

    ///utilizo precioUnit como acumulador, por cada codigo de libro
    return;

}

int tVectorInsertarOrdenadoyActualizar_ALU(tVector * vec, void* elem, cpm_ALU comp, Actualizar_ALU fusionar)
{
    if(vec->tam == vec->ce)
    {
        size_t nuevoCap = vec->tam + 20;
        void *dir = realloc(vec->dirI,vec->tamTD * nuevoCap);
        if(!dir)
            return SIN_MEM;
        vec->dirI = dir;
        vec->tam = nuevoCap;
    }
    void *j;
    void *i = vec->dirI;
    void *ult = vec->dirI + (vec->ce-1) * (vec->tamTD);
    while(i <= ult && comp(elem, i) > 0) ///elem es aux, e i es la posicion del vector
        i += vec->tamTD;

    if(i <= ult && comp(elem, i) == 0)
    {
        fusionar(i, elem);
        return TODO_OK;
    }

    for(j = ult ; j >= i ; j-= vec->tamTD)
        memcpy(j+vec->tamTD, j, vec->tamTD);

    memcpy(i, elem, vec->tamTD);
    vec->ce++;
    return TODO_OK;
}
int compararBusquedaBin_ALU(void* a, void* b)
{
    char *cod = (char*)a;

    Indice aux = *(Indice*)b;
    return strcmpi(cod, aux.codCliente);
}

void* busquedaBinaria_ALU(tVector* vecVentas, void* elem, cpm_ALU comp)
{
    void* inicio = vecVentas->dirI;
    void* ult = inicio + (vecVentas->ce-1) * vecVentas->tamTD;
    size_t mid = (ult - inicio)/2;
    mid += mid%vecVentas->tamTD;
    void* mitad = inicio + mid;
    int ret = comp(elem, mitad);
    while(inicio <= ult)
    {
        if(!ret)
            return mitad;
        if(ret > 0)
            inicio = mitad + vecVentas->tamTD;
        if(ret < 0)
            ult = mitad - vecVentas->tamTD;
        mid = (ult - inicio)/2;
        mid += mid%vecVentas->tamTD;
        mitad = inicio + mid;
        ret = comp(elem, mitad);
    }
    return NULL;
}

void mostrarVentas_ALU(void* i)
{
    Venta aux = *(Venta*)i;
    printf("%s | %s | %.2f | %d\n", aux.codCliente, aux.codProd, aux.precioUnit, aux.cantidad);
}

int bonificarClientes_ALU(const char* clientes, const char* clientesInd, const char* ventas)
{
/// Inserte el codigo aca ...
    FILE* archivoClientes;
    FILE* archivoIdx;
    FILE* archivoVentas;
    tVector vecIdx, vecVentas;
    Indice auxIndice;
    Venta auxVenta;
    Cliente auxCliente;
    ///para actualizar
    char codigoCliente[16];
    Venta* ppAuxVenta;
    Venta *ultVen = (Venta*)vecVentas.dirI + (vecVentas.ce-1) * vecVentas.tamTD;
    int nroReg;
    ///
    if(tVectorCrear_ALU(&vecIdx, sizeof(Indice), 10) == SIN_MEM)
        return SIN_MEM;
    archivoIdx = fopen(clientesInd, "rb"); ///ordenado por codigo
    if(!archivoIdx)
    {
        printf("No se pudo abrir el archivo %s", clientesInd);
        return NO_FILE;
    }
    fread(&auxIndice, sizeof(Indice), 1, archivoIdx);
    while(!feof(archivoIdx))
    {
        tVectorInsertarAlFinal_ALU(&vecIdx, &auxIndice);
        fread(&auxIndice, sizeof(Indice), 1, archivoIdx);
    }
    ///indice cargado!
    ///Ahora tengo que cargar el archivo ventas en memoria(no dice nada de NO bajar el archivo ventas en memoria)
    if(tVectorCrear_ALU(&vecVentas, sizeof(Venta), 10) == SIN_MEM)
        return SIN_MEM;
    archivoVentas = fopen(ventas, "rb");
    if(!archivoVentas)
    {
        printf("No se pudo abrir el archivo %s", ventas);
        fclose(archivoIdx);
        return NO_FILE;
    }

    fread(&auxVenta, sizeof(Venta), 1, archivoVentas);
    auxVenta.precioUnit = auxVenta.precioUnit * auxVenta.cantidad;
    while(!feof(archivoVentas))
    {
        tVectorInsertarOrdenadoyActualizar_ALU(&vecVentas, &auxVenta, compararVentas_ALU, actualizarVentas_ALU);
        fread(&auxVenta, sizeof(Venta), 1, archivoVentas);
        auxVenta.precioUnit = auxVenta.precioUnit * auxVenta.cantidad;
    }
    printf("\n\n");
    tVectorMostrar_ALU(&vecIdx, mostrarIdx_ALU);
    ///Indice y archivo Ventas cargados
    ///Ahora tengo que leer el primer registro de ventas, obtener buscar su codigo y buscarlo en el archivo indice, fijarme su monto y actualizar el Clientes.dat
    archivoClientes = fopen(clientes, "r+b");
    if(!archivoClientes)
    {
        printf("No se pudo abrir el archivo %s", clientes);
        fclose(archivoIdx);
        fclose(archivoVentas);
        return NO_FILE;
    }

    for(ppAuxVenta = (Venta*)vecVentas.dirI; ppAuxVenta <= ultVen ; ppAuxVenta++) ///for por todo vecVenta
    {
        strcpy(codigoCliente, ppAuxVenta->codCliente);
        nroReg = ((Indice*)busquedaBinaria_ALU(&vecIdx, codigoCliente, compararBusquedaBin_ALU))->nroReg;
        fseek(archivoClientes, (long)nroReg * sizeof(Cliente), SEEK_SET);
        fread(&auxCliente, sizeof(Cliente), 1, archivoClientes);
        if(ppAuxVenta->precioUnit >= 300000.00)
            auxCliente.porcBonif = 0.2;
        if(ppAuxVenta->precioUnit < 300000.00 && ppAuxVenta->precioUnit >= 200000.00)
            auxCliente.porcBonif = 0.1;
        if(ppAuxVenta->precioUnit < 200000.00 && ppAuxVenta->precioUnit >= 100000.00)
            auxCliente.porcBonif = 0.05;
        fseek(archivoClientes,(long) - sizeof(Cliente),SEEK_CUR);
        printf("%s - %s - %.2f\n", auxCliente.codigo, auxCliente.nombre, auxCliente.porcBonif); ///carga bien
        fwrite(&auxCliente, sizeof(Cliente), 1, archivoClientes);
    }
    fclose(archivoIdx);
    fclose(archivoVentas);
    fclose(archivoClientes);
    tVectorDestruir_ALU(&vecIdx);
    tVectorDestruir_ALU(&vecVentas);
    return TODO_OK;
}

void* buscarMm_ALU(void* inicio, void* fin, size_t tamTD, cpm_ALU comparacion)
{
    void* Mm = inicio, *i;
    for(i = inicio + tamTD; i <= fin; i+= tamTD)
    {
        if(comparacion(i, Mm) < 0)
            Mm = i;
    }
    return Mm;
}

void intercambiar_ALU(void* a, void*b, size_t tamTD)
{
    void* aux = malloc(tamTD);

    memcpy(aux, a, tamTD);
    memcpy(a, b, tamTD);
    memcpy(b, aux, tamTD);
    free(aux);
}
void ordenarSeleccionGen_ALU(tVector* vec, cpm_ALU comparacion)
{
    void* inicio, *ult = vec->dirI + (vec->ce-1)* vec->tamTD;
    void* elem;

    for(inicio = vec->dirI; inicio <= ult; inicio += vec->tamTD)
    {
        elem = buscarMm_ALU(inicio, ult, vec->tamTD,comparacion);
        intercambiar_ALU(inicio, elem, vec->tamTD);
    }
}


int compararOrdenamiento_ALU(void* a, void* b)
{
    Cliente aux1 = *(Cliente*)a;
    Cliente aux2 = *(Cliente*)b;
    return aux1.porcBonif - aux2.porcBonif;
}
void mostrarClientes_ALU(void* a)
{
    Cliente aux = *(Cliente*)a;
    printf("%s - %s - %.2f", aux.codigo, aux.nombre, aux.porcBonif);
}
void listarClientesOrdXBonifDesc_ALU(const char* clientes)
{
/// Inserte el codigo aca ...
    Cliente aux;
    FILE* archivo = fopen(clientes, "rb");
    if(!archivo)
        return;
    tVector vectorClientes;
    tVectorCrear_ALU(&vectorClientes, sizeof(Cliente), 10);

    fread(&aux, sizeof(Cliente), 1, archivo);
    while(!feof(archivo))
    {
        tVectorInsertarAlFinal_ALU(&vectorClientes, &aux);
        fread(&aux, sizeof(Cliente), 1, archivo);
    }
    ordenarSeleccionGen_ALU(&vectorClientes, compararOrdenamiento_ALU);
    tVectorMostrar_ALU(&vectorClientes, mostrarClientes_ALU);
    fclose(archivo);
    tVectorDestruir_ALU(&vectorClientes);

}

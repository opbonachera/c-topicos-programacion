#ifndef BIB_H_INCLUDED
#define BIB_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#define MAX_FIL 50
#define MAX_COL 50

void transponerMatriz(int mat[][MAX_COL], int filas, int columnas);
void *rBinarySearch( void *vec,  void *buscado, size_t ce, size_t tam, int (*comparar)( void *, void *));
int cmpInt(void* a, void* b);
#endif // BIB_H_INCLUDED

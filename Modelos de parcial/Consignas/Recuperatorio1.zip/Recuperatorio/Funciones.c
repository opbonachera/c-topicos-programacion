#include "Bib.h"


void transponerMatriz(int mat[][MAX_COL], int filas, int columnas)
{   int i,j, aux, filFinal=filas,ColFinal=columnas;

    if(filas!=columnas)  ///Para casos impares
    {   filFinal=columnas;
        ColFinal=filas;
    }
    for(i=0;i<filFinal;i++)
    {     for(j=i+1;j<=ColFinal;j++)
            {
              aux=mat[i][j];
              mat[i][j]=mat[j][i];
              mat[j][i]=aux;
            }
    }

    for(i=0;i<filFinal;i++)
    {   for(j=0;j<ColFinal;j++)
            {
              printf("%d ", mat[i][j]);
            }
        printf("\n");
    }
}
//disculpe profe no pude sacarlo me puse nervioso pero le dejo detallado el procedimiento porque si lo entiendo :c
void *rBinarySearch( void *vec, void *elemento, size_t ce, size_t tam, int (*comparar)(void *, void *))
{   void* pIni, *pFin, *medio, *Resultado;
    int *aux; aux=0;
    pIni=vec;   ///Define posiciones de punteros
    pFin=vec+(ce-1)*tam;
    medio=vec+(pFin-pIni)/tam/2*tam;
    while(pIni<=pFin)
    {   *aux=cmpInt(medio, elemento);   ///Mi caso base
        if (aux==(int*)medio)           ///Si llega a encontrarlo lo devuelve para evitar que siga ciclando
            {   Resultado=(void*)aux;
                return Resultado;
            }
        if((*aux)<0)
        {     pIni=medio+tam;   ///Le cambio el inicio para que pueda ir desde el medio+1 hasta ce/2
            return(rBinarySearch(pIni,&elemento,(ce/2),sizeof(int),cmpInt));
        }
        if((*aux)>0)
        {   ///Le envio el mismo inicio pero hasta la mitad de la ce
            return(rBinarySearch(pIni,&elemento,(ce/2),sizeof(int),cmpInt));
        }
    }
    return NULL; ///Para estar seguros de que no se vaya a ningun lado la funcion
}
/*void *BinarySearch( void *vec, void *elemento, size_t ce, size_t tam, int (*comparar)(void *, void *))
{   void* pIni, *pFin, *medio;
    int *aux;
    pIni=vec;
    pFin=vec+(ce-1)*tam;
    medio=vec+(pFin-pIni)/tam/2*tam;
    while(pIni<=pFin)
    {   *aux=cmpInt(medio, elemento);
        if (aux==(int*)medio)
            return aux;
        if((*aux)<0)
        {
            pIni=medio+tam;
        }
        if((*aux)>0)
        {
            pFin=medio-tam;
        }
        medio=vec+(pFin-pIni)/tam/2*tam;
    }
    return NULL;
}*/

int cmpInt(void* a, void* b)
{   return (*(int*)a)-(*(int*)b);
}

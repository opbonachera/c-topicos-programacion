#include "Bib.h"

int main()
{   int vec[15]={0,2,3,4,5,7,9,11,15}; ///Defino el vec mas grande para comprobar que el pFin se establece bien
    int *elementoPtr;
    int buscado=11;
    int ce=9;
    /*
    Casos de prueba pares e impares
    int mat1[MAX_FIL][MAX_COL]={{1,2,3},
                               {4,5,6},
                               {7,8,9}};
   int mat2[MAX_FIL][MAX_COL]={{1,2},
                               {3,4},
                               {5,6}};
   int mat3[MAX_FIL][MAX_COL]={{1,2,3},
                               {4,5,6}};
    transponerMatriz(mat1,3,3);*/
/// Punto 2 ------------
/// Punto 1 ------------
    elementoPtr=rBinarySearch(vec, &buscado, ce, sizeof(int), cmpInt);
    printf("Elemento buscado: %d\nElemento encontrado: %d", buscado, *elementoPtr);
    return 0;
}

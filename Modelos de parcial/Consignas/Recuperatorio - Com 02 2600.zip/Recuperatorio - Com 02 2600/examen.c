#include <stdio.h>
#include "examen.h"

int multiplicarMatricesAlumno(int mat1[][MAX_COL],
                        int fmat1,
                        int cmat1,
                        int mat2[][MAX_COL],
                        int fmat2,
                        int cmat2,
                        int matR[][MAX_COL]){
    ///implementar logica aqui
    return 0;///modifique el valor de retorno segun lo que necesite
}


char *rstrrchrAlumno(const char *cad, int c){
    ///implementar logica aqu�
    return NULL;
}

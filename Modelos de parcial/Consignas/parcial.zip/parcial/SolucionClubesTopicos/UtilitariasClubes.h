#ifndef UTILITARIAS_CLUBES_H
#define UTILITARIAS_CLUBES_H


void generarArchivoSociosClubA(const char* nombreArchivoSociosA);
void generarArchivoSociosClubB(const char* nombreArchivoSociosB);
void generarArchivoSociosClubBTxtDesord(const char* nombreArchivoSociosClubB);
void mostrarArchSociosA(const char* nombreArchivoSociosA);
void mostrarArchSociosBBin(const char* nombreArchivoSociosB);
void mostrarArchSociosBTxt(const char* nombreArchivoSociosB);


#endif // UTILITARIAS_H

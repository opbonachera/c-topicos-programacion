#ifndef ARCHIVO_H
#define ARCHIVO_H

#include <stdio.h>

#define TODO_OK 0
#define ERR_ARCHIVO 1


typedef struct
{
	char codSocio[11];
	char apyn[51];
	int antiguedad;
}
SocioA;


typedef struct
{
	int nroSocio;
	char apyn[51];
	int antiguedad;
}
SocioB;

int fusionarArchivos(const char* nombreSociosClubA, const char* nombreSociosClubBTxt, const char* nombreSociosFus);

#endif // ARCHIVO

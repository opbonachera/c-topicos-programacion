#ifndef FUNCIONES_GRUPO_H_INCLUDED
#define FUNCIONES_GRUPO_H_INCLUDED
/*
Aquí deben hacer los includes de sus archivos individuales, por ejemplo:
#include "funciones_machi.h"
 */
#include "funciones_bonachera.h"
#include "funciones_fernandez.h"
#include "funciones_risso.h"
#include "funciones_defensa_fernandez.h"


int solucion(int argc, char* argv[]);


#endif // FUNCIONES_GRUPO_H_INCLUDED

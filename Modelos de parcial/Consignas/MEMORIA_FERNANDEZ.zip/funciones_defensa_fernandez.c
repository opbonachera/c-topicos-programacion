#include "funciones_defensa_fernandez.h"


int metamor(FILE* img1, FILE* img2, char* nombreNuevoArchivo, char* parametros)
{
    int n, m;

    parametros = strchr(parametros, '=');
    parametros++;

    sscanf(parametros, "%d", &n);

    parametros = strchr(parametros, '=');
    parametros++;

    sscanf(parametros, "%d", &m);

    FILE* imgNueva = fopen(nombreNuevoArchivo, "wb");

    if(!imgNueva)
    {
        printf("\nError al crear la nueva imagen.");
        return ERROR_CREACION_ARCHIVO;
    }

    t_metadata cabecera1, cabecera2;
    leerCabecera(img1, &cabecera1);
    leerCabecera(img2, &cabecera2);

    if(cabecera1.alto != cabecera2.alto || cabecera1.ancho != cabecera2.ancho)
    {
        fclose(imgNueva);
        return ERR_TAM_IMG;
    }

    escribirCabecera(img1, imgNueva, &cabecera1);

    t_pixel** matImg1 = (t_pixel**)matrizCrear(sizeof(t_pixel), cabecera1.alto, cabecera1.ancho);
    t_pixel** matImg2 = (t_pixel**)matrizCrear(sizeof(t_pixel), cabecera2.alto, cabecera2.ancho);
    t_pixel** matImgNueva = (t_pixel**)matrizCrear(sizeof(t_pixel), cabecera1.alto, cabecera1.ancho);

    fseek(img2, cabecera2.comienzoImagen,SEEK_SET);

    cargarMatriz(img1, matImg1, cabecera1.alto, cabecera1.ancho);
    cargarMatriz(img2, matImg2, cabecera2.alto, cabecera2.ancho);

    for(int i=0; i<cabecera1.alto; i+=(2*m))
    {
        for(int t=i; t<cabecera1.alto && t<i+m; t++)
        {
            for(int k=0; k<cabecera1.ancho; k+=(2*n))
            {
                for(int j=k; j<cabecera1.ancho && j<k+n; j++)
                {
                    matImgNueva[t][j].pixel[0] = matImg1[t][j].pixel[0];
                    matImgNueva[t][j].pixel[1] = matImg1[t][j].pixel[1];
                    matImgNueva[t][j].pixel[2] = matImg1[t][j].pixel[2];
                }
                for(int j=k+n; j<cabecera1.ancho && j<k+(2*n); j++)
                {
                    matImgNueva[t][j].pixel[0] = matImg2[t][j].pixel[0];
                    matImgNueva[t][j].pixel[1] = matImg2[t][j].pixel[1];
                    matImgNueva[t][j].pixel[2] = matImg2[t][j].pixel[2];
                }
            }
        }
        for(int t=i+m; t<cabecera1.alto && t<i+(2*m); t++)
        {
            for(int k=0; k<cabecera1.ancho; k+=(2*n))
            {
                for(int j=k; j<cabecera1.ancho && j<k+n; j++)
                {
                    matImgNueva[t][j].pixel[0] = matImg2[t][j].pixel[0];
                    matImgNueva[t][j].pixel[1] = matImg2[t][j].pixel[1];
                    matImgNueva[t][j].pixel[2] = matImg2[t][j].pixel[2];
                }
                for(int j=k+n; j<cabecera1.ancho && j<k+(2*n); j++)
                {
                    matImgNueva[t][j].pixel[0] = matImg1[t][j].pixel[0];
                    matImgNueva[t][j].pixel[1] = matImg1[t][j].pixel[1];
                    matImgNueva[t][j].pixel[2] = matImg1[t][j].pixel[2];
                }
            }
        }
    }


    escribirArchivo(imgNueva, matImgNueva, cabecera1.alto, cabecera1.ancho);

    matrizDestruir((void**)matImg1, cabecera1.alto);
    matrizDestruir((void**)matImg2, cabecera2.alto);
    matrizDestruir((void**)matImgNueva, cabecera1.alto);
    fclose(imgNueva);

    return OK;
}

#ifndef FUNCIONES_DEFENSA_FERNANDEZ_H_INCLUDED
#define FUNCIONES_DEFENSA_FERNANDEZ_H_INCLUDED

#include "funciones_grupo.h"

#define ERR_TAM_IMG 100

int metamor(FILE* img1, FILE* img2, char* nombreNuevoArchivo, char* parametros);

#endif // FUNCIONES_DEFENSA_FERNANDEZ_H_INCLUDED
